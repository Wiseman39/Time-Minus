To use this database, please install XAMPP (https://www.apachefriends.org/xampp-files/7.4.8/xampp-windows-x64-7.4.8-0-VC15-installer.exe)

To use XAMPP run the executable file xampp-control.exe (default location is "C:\xampp\xampp-control.exe")

To get XAMPP up-and-running:

1.Start Apache and MySQL

2.click the Config button next to Apache and then PHP (php.ini)

3.In the text file press Ctrl+H to bring up the "Find and Replace" dialogue

4.Type "3306" into Find What without the quotations and "3307" into Replace With without quotations and press Replace All.

5. Close the text file and click Config next to MySQL in the control panel. In the menu select my.ini.

6. Repeat steps 3 and 4 in this text file aswell.


To get the server up-and-running:

1. In the XAMPP control panel, click the admin button next to MySQL. This will open up in your default browser.

2. On the left click "new". Enter the database name "timeminus" without the quotes into the Database Name text box and press Create.

3.Click on timeminus on the left and then click Import on the top bar. Click choose file and select the database file "timeminus.sql".

4.The database should now be loaded and ready for the application to use. Close the browser window.

p.s. Derrick I know the database looks like a mess but I already have an idea to sort it out okay?

